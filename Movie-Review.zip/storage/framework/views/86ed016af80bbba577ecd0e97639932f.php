<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Test Questions')); ?>

        </h2>

        <?php if( json_decode(\Auth::user(), true)['role'] == 1 ): ?>
        <a href="/test/create" class="mt-2 inline-block bg-blue-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2"><?php echo e(__('Create new question')); ?></a>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>
    <form method="POST" action="<?php echo e(route('answers.post')); ?>">
        <?php echo csrf_field(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-3 gap-4">
                <?php $__currentLoopData = $TestQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="max-w-sm rounded overflow-hidden shadow-lg">
                    <div class="px-6 py-4">
                      <div class="font-bold text-xl mb-2"><?php echo e($Question->title); ?></div>
                      <p class="text-gray-700 text-base"><?php echo e($Question->question); ?></p>
                    </div>
                    <?php
                        $Answers = preg_split('/,/', $Question->choices);
                    ?>
                    <?php if(count($Answers) > 1): ?>
                    <select required name="answers[<?php echo e($Question->id); ?>]" class="inline-block rounded-full px-3 py-1 text-sm font-semibold text-gray-700 ml-2 mb-2">
                        <?php $__currentLoopData = $Answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($Answer); ?>"><?php echo e($Answer); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php else: ?>
                    <textarea name="answers[<?php echo e($Question->id); ?>]" required class="mr-2 ml-1 block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6 p-3"></textarea>
                    <?php endif; ?>
                    <?php if( json_decode(\Auth::user(), true)['role'] == 1 ): ?>
                    <div class="px-6 pt-4 pb-2">
                        <a href="/test/delete/<?php echo e($Question->id); ?>" class="inline-block bg-red-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2"><?php echo e(__('Delete')); ?></a>
                        </div>

                    <?php endif; ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div>

              <?php if( json_decode(\Auth::user(), true)['role'] == 2 ): ?>
              <button type="submit" class="mt-2 inline-block bg-blue-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2"><?php echo e(__('Submit Answers')); ?></button>
              <?php endif; ?>
         </div>
    </div>

</form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\DELL\Desktop\Movie-Review\resources\views/test/index.blade.php ENDPATH**/ ?>