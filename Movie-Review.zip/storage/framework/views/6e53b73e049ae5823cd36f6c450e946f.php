<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Movies > Review > ')); ?> <?php echo e($Movie->title); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <iframe width="100%" height="" style="height: 66vh;" src="<?php echo e($Movie->link); ?>&amp;controls=0" frameborder="0" allowfullscreen></iframe>
        </div>

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
<form method="POST" action="<?php echo e(route('movies.create.review.post')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="movie_id" value="<?php echo e($Movie->id); ?>" />
    <input type="hidden" name="user_id" value="<?php echo e(\Auth::id()); ?>" />
    <div class="space-y-12">

      <div class="border-b border-gray-900/10 pb-12">
        <div class="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
            <div class="sm:col-span-6">
                <?php echo e($Movie->description); ?>

            </div>

            <?php
                $selected = $Review->rating?? 0;
            ?>
          <div class="sm:col-span-3">
            <label for="rating" class="block text-sm font-medium leading-6 text-gray-900"><?php echo e(__('Rating')); ?></label>
            <div class="mt-2">
              <select name="rating" id="rating" class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6 p-3">
                    <option value="0" <?php if($selected == 0): ?> selected <?php endif; ?>><?php echo e(__('Terrible')); ?> 0/5</option>
                    <option value="1" <?php if($selected == 1): ?> selected <?php endif; ?>><?php echo e(__('Awful')); ?> 1/5</option>
                    <option value="2" <?php if($selected == 2): ?> selected <?php endif; ?>><?php echo e(__('Bad')); ?> 2/5</option>
                    <option value="3" <?php if($selected == 3): ?> selected <?php endif; ?>><?php echo e(__('Average')); ?> 3/5</option>
                    <option value="4" <?php if($selected == 4): ?> selected <?php endif; ?>><?php echo e(__('Good')); ?> 4/5</option>
                    <option value="5" <?php if($selected == 5): ?> selected <?php endif; ?>><?php echo e(__('Excellent')); ?> 5/5</option>
              </select>
            </div>
          </div>

          <div class="sm:col-span-4">
            <label for="review" class="block text-sm font-medium leading-6 text-gray-900"><?php echo e(__('Review')); ?></label>
            <div class="mt-2">
              <textarea name="review" id="review" class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6 p-3"><?php echo e(__($Review->review??'Write your thoughts on the movie here...')); ?></textarea>
            </div>
          </div>

          <button type="submit" class="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Send</button>

        </div>
      </div>
      </div>
  </form>

         </div>
    </div>

    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 pb-5">
        <h1 class="text-gray-900 font-bold text-xl mb-2"><?php echo e(__('Reviews')); ?></h1>
    <ul class="bg-white rounded-lg shadow divide-y divide-gray-200 ">
        <?php $__currentLoopData = $Reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userReview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li class="px-6 py-4">
            <div class="flex justify-between">
                <span class="font-semibold text-lg"><?php echo e($userReview->name); ?></span>
                <span class="text-gray-500 text-xs"><?php echo e($userReview->Rating); ?>/5</span>
            </div>
            <p class="text-gray-700"><?php echo e($userReview->Review); ?></p>
        </li>

    </ul>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\DELL\Desktop\Movie-Review\resources\views/movies/review.blade.php ENDPATH**/ ?>